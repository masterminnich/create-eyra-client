module.exports = {
    env: {
        MONGO_URI: 'mongodb+srv://admin:r3cwWwufcTuoyTYk@m0cluster.hqusv.mongodb.net/mainDB?retryWrites=true&w=majority'
    }
}